#include <iostream>
#include <vector>
using namespace std;

class Presentation {
public:
    static string representInputBitSequence(int, string);
    static string representOutputBitSequence(vector<int>);
};